/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Standalone output keeps the Docker image small; ignored by Vercel.
  output: "standalone",
  experimental: {
    // pdf-parse must stay a plain Node require on the server
    serverComponentsExternalPackages: ["pdf-parse"]
  }
};

module.exports = nextConfig;
