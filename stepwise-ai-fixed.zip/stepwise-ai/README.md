# StepWise AI

Interactive AI learning board (Next.js 14, API routes, cookie auth, JSON file DB).

## Run locally
```bash
npm install
cp .env.example .env.local   # set AUTH_SECRET
npm run dev                  # http://localhost:3000
```
Works out of the box with `AI_PROVIDER=mock`. Add `GEMINI_API_KEY` / `OPENAI_API_KEY` for real AI.

## Deploy (GitHub Pages will NOT work)
This app has a backend (API routes, login, uploads), and GitHub Pages only hosts static files.
Push this repo to GitHub, then import it into one of:

**Vercel (easiest)** – vercel.com → Add New Project → pick the repo → add env vars `AUTH_SECRET`
(+ `GEMINI_API_KEY` / `OPENAI_API_KEY`) → Deploy. Note: data lives in `/tmp`, so accounts reset
on cold starts (fine for a demo).

**Render (keeps data)** – render.com → New → Blueprint → pick the repo. `render.yaml` sets up
Docker + a persistent disk and generates `AUTH_SECRET`. Add your API keys in the dashboard.

**Any Docker host** – `docker build -t stepwise . && docker run -p 3000:3000 -e AUTH_SECRET=xxx -v stepwise:/data stepwise`

Docs/specs: `docs/`. Smoke tests: `node scripts/smoke.mjs` (with the app running).
